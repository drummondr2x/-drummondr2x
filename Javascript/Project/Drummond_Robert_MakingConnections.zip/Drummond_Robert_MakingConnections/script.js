

function takeAway(element) {
        console.log("Delete User");
        document.getElementById("user", "user1").remove();
}


function changeName() {
    document.querySelector("#profile").innerHTML = "Ally Davis";
} 